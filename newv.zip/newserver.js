const express = require('express')
const app = express();
const { MongoClient } = require("mongodb");
const jwt = require('jsonwebtoken')
const bcrypt = require('bcrypt');
const port = 4000;
const dotenv = require('dotenv'); // Load environment variables

dotenv.config(); // Load environment variables from a `.env` file

const key = process.env.JWT_SECRET; // Access the secret key
//var cors = require('cors')
//app.use(cors())
app.use(express.json());


app.use(express.static('build'))

const client = new MongoClient("mongodb://127.0.0.1:27017");

async function connectToDb() {
    try {
        await client.connect();
        console.log('MongoDB connected');
    } catch (err) {
        console.error(err);
        process.exit(1); // Exit on connection error
    }
}

connectToDb(); // Connect to MongoDB on startup

function capitalizeFLetter(str) {
    return (str[0].toUpperCase() + str.slice(1));
}

function tryGetEmailFromJwt(req) {
    try {
        const authHeader = req.headers['authorization']
    const token = authHeader && authHeader.split(' ')[1]
      const parts = token.split('.');
      if (parts.length !== 3) {
        return null; // Not a valid JWT structure
      }
      const decodedPayload = Buffer.from(parts[1], 'base64').toString('utf-8');
      const payloadObject = JSON.parse(decodedPayload);
      return payloadObject.access; // Assuming email is stored in the payload
    } catch (error) {
      console.error(error);
      return null;
    }
  }

async function isEmailPresent(email, client) {
    try {
        const db = client.db("UserDB");
        const collection = db.collection("pusers");
        const user = await collection.findOne({ email }); // Find user by email
        
        return !!user; // Returns true if user exists, false otherwise
    } catch (error) {
        console.error(error);
        throw error; // Re-throw the error for handling in the calling function
    }
}

app.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        // Validate user input
        if (!email || !password) {
            return res.status(400).json({ message: 'Missing required fields' });
        }

        // Find the user by username
        const db = client.db("UserDB");
        const collection = db.collection('users');
        const user = await collection.findOne({ email });

        if (!user) {
            return res.status(401).json({ message: 'Invalid username or password' });
        }

        // Compare hashed passwords
        const match = await bcrypt.compare(password, user.password);
        if (!match) {
            return res.status(401).json({ message: 'Invalid email or password' });
        }

        // Login successful (optional: generate a JWT token here for further authentication)
        const user_s = { email: req.body.email , access:user.access}
        const accessToken = jwt.sign(user_s, key, { expiresIn: '30m' })
        res.send({ status: 'success', accessToken: accessToken })
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

function authenticationToken(req, res, next) {
    const authHeader = req.headers['authorization']
    const token = authHeader && authHeader.split(' ')[1]
    if (token == null) return res.sendStatus(401)

    jwt.verify(token, key, (err, user) => {
        if (err) return res.send({ status: 'login' })
        next()
    })
}

async function connectAndFetchData(collectionName, res) {
    try {
        const db = client.db("Zones");
        const collection = db.collection(collectionName);
        const results = await collection.find({}).toArray();
        res.send(results);
    } catch (error) {
        console.error("Error fetching data:", error); // More informative error message
        // Handle specific error types if needed (e.g., network errors)
    } finally {
        // Optional: Consider connection pooling strategies like releasing connections back to the pool
    }
}

//admin
var structLoss = (reqbody,res) => {
    async function run() {
        try {
            const db = client.db("Zones")
            const cll = db.collection(capitalizeFLetter(reqbody.db))
            const result = await cll.updateOne({ticker:reqbody.name},{'$set':{'zone.0.loss':reqbody.loss}})
            //const result = await cll.find({'ticker':reqbody.name}).toArray()
            //console.log(time,oi)
            if(result.acknowledged == true && result.modifiedCount == 1){
                res.send({status:'success'})
            }else{
                res.send({status:'failed'})
            }
        } catch (e) {
            console.log("Error:niftyoi " + "{time:" + e + "}");
        } finally {
            //await client.close();
        }
    } run().catch(console.dir);
}
var structTested = (reqbody,res) => {
    async function run() {
        try {
            const db = client.db("Zones")
            const cll = db.collection(capitalizeFLetter(reqbody.db))
            const result = await cll.updateOne({ticker:reqbody.name},{'$set':{'zone.0.tested':reqbody.tested}})
            //const result = await cll.find({'ticker':reqbody.name}).toArray()
            //console.log(time,oi)
            if(result.acknowledged == true && result.modifiedCount == 1){
                res.send({status:'success'})
            }else{
                res.send({status:'failed'})
            }
        } catch (e) {
            console.log("Error:niftyoi " + "{time:" + e + "}");
        } finally {
            //await client.close();
        }
    } run().catch(console.dir);
}


app.get('/poll',authenticationToken, (req, res) => {
    res.send({status:'success'})
})
// User registration endpoint
app.post('/register', async (req, res) => {
    try {
        const { email, password } = req.body;
        const access = "basic"
        // Validate user input (optional)
        if (!email || !password) {
            return res.status(400).json({ message: 'Missing required fields' });
        }

        // Check for existing user
        const db = client.db('UserDB');
        const collection = db.collection('users');
        const existingUser = await collection.findOne({ email });
        if (existingUser) {
            return res.status(409).json({ message: 'Email already exists' });
        }

        // Hash the password
        const saltRounds = 10;
        const hash = await bcrypt.hash(password, saltRounds);

        // Create new user document
        const newUser = { email, password: hash, access };

        // Insert user into the database
        await collection.insertOne(newUser);

        res.status(201).json({ message: 'User created successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Internal Server Error' });
    }
});

// Usage example:
app.get('/niftyMidCap150D', authenticationToken,(req, res) => {
    if(tryGetEmailFromJwt(req) == "basic") return res.sendStatus(401)
    connectAndFetchData('NiftyMidCap150D', res);
});

app.get('/niftyOtherD',authenticationToken,(req, res) => {
    if(tryGetEmailFromJwt(req) == "basic") return res.sendStatus(401)
    connectAndFetchData('NiftyOtherD', res);
})

app.get('/niftySmCap250D',authenticationToken,(req, res) => {
    if(tryGetEmailFromJwt(req) == "basic") return res.sendStatus(401)
    connectAndFetchData('NiftySmCap250D', res);
})

app.get('/niftyOtherD',authenticationToken,(req, res) => {
    if(tryGetEmailFromJwt(req) == "basic") return res.sendStatus(401)
    connectAndFetchData('NiftyOtherD', res);
})

app.get('/niftyNxt50',authenticationToken,(req, res) => {
    if(tryGetEmailFromJwt(req) == "basic") return res.sendStatus(401)
    connectAndFetchData('NiftyNxt50', res);
})

app.get('/Nifty50D', authenticationToken, (req, res) => {
    connectAndFetchData('Nifty50D', res);
});

//Weekly
app.get('/Nifty50W', authenticationToken, (req, res) => {
    if(tryGetEmailFromJwt(req) == "basic") return res.sendStatus(401)
    connectAndFetchData('Nifty50W', res);
});
//Admin
app.post('/tested', (req, res) => {
    structTested(req.body,res)
})

app.post('/stoploss', (req, res) => {
    structLoss(req.body,res)
})

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})