
console.log("Data fetcher script started")
setInterval(() => {
  var ticker = []
  fetch("https://www.nseindia.com/api/equity-stockIndices?index=NIFTY%20TOTAL%20MARKET") // Replace with your specific URL to fetch
    .then(response => response.json())
    .then(data => {
      for (i = 1; i <= data.data.length - 1; i++) {
        ticker.push({ ticker: data.data[i].symbol, ltp: data.data[i].lastPrice, time: data.data[i].lastUpdateTime })
      }
      chrome.runtime.sendMessage({ action: "sendData", data: JSON.stringify(ticker) });
      console.log((ticker.length))
    })
    .catch(error => {
      console.error(error);
    });
}, 60000)

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "triggerFetch") {
    sendResponse({ action: "fetchStarted" }); // Optional: Send a response to indicate fetch initiated
  }
});
