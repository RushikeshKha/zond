const express = require('express')
const app = express();
const { MongoClient } = require("mongodb");
const jwt = require('jsonwebtoken')
const port = 4000;
//var cors = require('cors')
//app.use(cors())
app.use(express.json());

const key = "e5c9100c84946f8ab0e77549a7ea63595b94b9ca8522f0aac04d36702e68223e"

app.use(express.static('build'))

const client = new MongoClient("mongodb://127.0.0.1:27017");

var NiftyMidCap150 = (res) => {
    async function run() {
        try {
            await client.connect();
            const db = client.db("Zones")
            const cll = db.collection('NiftyMidCap50')
            const result = await cll.find({}).toArray()
            //console.log(time,oi)
            res.send(result)
        } catch (e) {
            console.log("Error:niftyoi " + "{time:" + e + "}");
        } finally {
            await client.close();
        }
    } run().catch(console.dir);
}

var NiftyNxt50 = (res) => {
    async function run() {
        try {
            await client.connect();
            const db = client.db("Zones")
            const cll = db.collection('NiftyNxt50')
            const result = await cll.find({}).toArray()
            //console.log(time,oi)
            res.send(result)
        } catch (e) {
            console.log("Error:niftyoi " + "{time:" + e + "}");
        } finally {
            await client.close();
        }
    } run().catch(console.dir);
}
var NiftyNxt50H = (res) => {
    async function run() {
        try {
            await client.connect();
            const db = client.db("Zones")
            const cll = db.collection('NiftyNxt50H')
            const result = await cll.find({}).toArray()
            //console.log(time,oi)
            res.send(result)
        } catch (e) {
            console.log("Error:niftyoi " + "{time:" + e + "}");
        } finally {
            await client.close();
        }
    } run().catch(console.dir);
}
var NiftyNxt50W = (res) => {
    async function run() {
        try {
            await client.connect();
            const db = client.db("Zones")
            const cll = db.collection('NiftyNxt50W')
            const result = await cll.find({}).toArray()
            //console.log(time,oi)
            res.send(result)
        } catch (e) {
            console.log("Error:niftyoi " + "{time:" + e + "}");
        } finally {
            await client.close();
        }
    } run().catch(console.dir);
}

var Nifty50D = (res) => {
    async function run() {
        try {
            await client.connect();
            const db = client.db("Zones")
            const cll = db.collection('Nifty50D')
            const result = await cll.find({}).toArray()
            //console.log(time,oi)
            res.send(result)
        } catch (e) {
            console.log("Error:niftyoi " + "{time:" + e + "}");
        } finally {
            await client.close();
        }
    } run().catch(console.dir);
}

var Nifty50W = (res) => {
    async function run() {
        try {
            await client.connect();
            const db = client.db("Zones")
            const cll = db.collection('Nifty50W')
            const result = await cll.find({}).toArray()
            //console.log(time,oi)
            res.send(result)
        } catch (e) {
            console.log("Error:niftyoi " + "{time:" + e + "}");
        } finally {
            await client.close();
        }
    } run().catch(console.dir);
}

var NiftyMidCap250D = (res) => {
    async function run() {
        try {
            await client.connect();
            const db = client.db("Zones")
            const cll = db.collection('NiftyMidCap250D')
            const result = await cll.find({}).toArray()
            //console.log(time,oi)
            res.send(result)
        } catch (e) {
            console.log("Error:niftyoi " + "{time:" + e + "}");
        } finally {
            await client.close();
        }
    } run().catch(console.dir);
}
var NiftyMidCap250W = (res) => {
    async function run() {
        try {
            await client.connect();
            const db = client.db("Zones")
            const cll = db.collection('NiftyMidCap250W')
            const result = await cll.find({}).toArray()
            //console.log(time,oi)
            res.send(result)
        } catch (e) {
            console.log("Error:niftyoi " + "{time:" + e + "}");
        } finally {
            await client.close();
        }
    } run().catch(console.dir);
}

var NiftySmCap250D = (res) => {
    async function run() {
        try {
            await client.connect();
            const db = client.db("Zones")
            const cll = db.collection('NiftySmCap250D')
            const result = await cll.find({}).toArray()
            //console.log(time,oi)
            res.send(result)
        } catch (e) {
            console.log("Error:niftyoi " + "{time:" + e + "}");
        } finally {
            await client.close();
        }
    } run().catch(console.dir);
}
var NiftySmCap250W = (res) => {
    async function run() {
        try {
            await client.connect();
            const db = client.db("Zones")
            const cll = db.collection('NiftySmCap250W')
            const result = await cll.find({}).toArray()
            //console.log(time,oi)
            res.send(result)
        } catch (e) {
            console.log("Error:niftyoi " + "{time:" + e + "}");
        } finally {
            await client.close();
        }
    } run().catch(console.dir);
}

var NiftyOtherD = (res) => {
    async function run() {
        try {
            await client.connect();
            const db = client.db("Zones")
            const cll = db.collection('NiftyOtherD')
            const result = await cll.find({}).toArray()
            //console.log(time,oi)
            res.send(result)
        } catch (e) {
            console.log("Error:niftyoi " + "{time:" + e + "}");
        } finally {
            await client.close();
        }
    } run().catch(console.dir);
}

var NiftyOtherW = (res) => {
    async function run() {
        try {
            await client.connect();
            const db = client.db("Zones")
            const cll = db.collection('NiftyOtherW')
            const result = await cll.find({}).toArray()
            //console.log(time,oi)
            res.send(result)
        } catch (e) {
            console.log("Error:niftyoi " + "{time:" + e + "}");
        } finally {
            await client.close();
        }
    } run().catch(console.dir);
}

var NiftyMidCap150H = (res) => {
    async function run() {
        try {
            await client.connect();
            const db = client.db("Zones")
            const cll = db.collection('NiftyMidCap150H')
            const result = await cll.find({}).toArray()
            //console.log(time,oi)
            res.send(result)
        } catch (e) {
            console.log("Error:niftyoi " + "{time:" + e + "}");
        } finally {
            await client.close();
        }
    } run().catch(console.dir);
}

var NiftySmCap250H = (res) => {
    async function run() {
        try {
            await client.connect();
            const db = client.db("Zones")
            const cll = db.collection('NiftySmCap250H')
            const result = await cll.find({}).toArray()
            //console.log(time,oi)
            res.send(result)
        } catch (e) {
            console.log("Error:niftyoi " + "{time:" + e + "}");
        } finally {
            await client.close();
        }
    } run().catch(console.dir);
}

function authenticationToken(req,res,next){
    const authHeader = req.headers['authorization']
    const token = authHeader && authHeader.split(' ')[1]
    if(token == null) return res.sendStatus(401)
    
    jwt.verify(token,key,(err,user) => {
        if(err) return res.send({status:'login'})
        next()
    })
}

app.post('/login', (req, res) => {
    if (req.body.email == "aaa" && req.body.password == "aaa"){
        
        const user = {email:req.body.email}
        const accessToken = jwt.sign(user,key,{expiresIn:'60m'})
        res.send({status:'success',accessToken:accessToken})
    }
    else{
        res.send({status:'invalid username or password'})
    }
    
})

app.get('/poll',authenticationToken, (req, res) => {
    res.send({status:'success'})
})

app.get('/niftyMidCap150H',authenticationToken, (req, res) => {
    NiftyMidCap150H(res)
})

app.get('/niftySmCap250H',authenticationToken, (req, res) => {
    NiftySmCap250H(res)
})
app.get('/niftyOtherD',authenticationToken, (req, res) => {
    NiftyOtherD(res)
})
app.get('/niftyOtherW', authenticationToken,(req, res) => {
    NiftyOtherW(res)
})
app.get('/niftySmCap250D',authenticationToken, (req, res) => {
    NiftySmCap250D(res)
})
app.get('/niftySmCap250W', authenticationToken,(req, res) => {
    NiftySmCap250W(res)
})
app.get('/niftyMidCap250D', authenticationToken,(req, res) => {
    NiftyMidCap250D(res)
})
app.get('/niftyMidCap250W',authenticationToken, (req, res) => {
    NiftyMidCap250W(res)
})
app.get('/nifty50D', authenticationToken,(req, res) => {
    Nifty50D(res)
})

app.get('/nifty50W', authenticationToken,(req, res) => {
    Nifty50W(res)
})
app.get('/niftyMidCap50H',authenticationToken, (req, res) => {
    NiftyMidCap50(res)
})

app.get('/niftyNxt50', authenticationToken,(req, res) => {
    NiftyNxt50(res)
})
app.get('/niftyNxt50H', authenticationToken,(req, res) => {
    NiftyNxt50H(res)
})
app.get('/niftyNxt50W', authenticationToken,(req, res) => {
    NiftyNxt50W(res)
})
app.get('/niftySmallCap', authenticationToken,(req, res) => {
    NiftyOI(res)
})

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})