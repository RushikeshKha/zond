chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "sendData") {
      fetch("http://localhost:8080/", {
        method: "POST",
        body: message.data
      })
        .then(response => console.log("Data sent to localhost"))
        .catch(error => console.error(error));
    }
  });
  