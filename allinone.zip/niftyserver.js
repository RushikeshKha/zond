const { MongoClient } = require("mongodb");


const client = new MongoClient("mongodb://127.0.0.1:27017");

async function connectToDb() {
  try {
    await client.connect();
    console.log('MongoDB connected');
  } catch (err) {
    console.error(err);
    process.exit(1); // Exit on connection error
  }
}

connectToDb();

async function listStock(ticker) {
  try {
      const db = client.db("Zones");
      const collection = db.collection("Nifty50D");
      const user = await collection.updateOne({ ticker:ticker },); // Find user by email
      console.log('asdf')
      console.log(user) // Returns true if user exists, false otherwise
  } catch (error) {
      console.error(error);
      throw error; // Re-throw the error for handling in the calling function
  }
}
fetch("https://iislliveblob.niftyindices.com/jsonfiles/equitystockwatch/EquityStockWatchNIFTY%20500.json?{}&_=" + JSON.stringify(Date.now()), {
  "headers": {
    "accept": "application/json, text/javascript, */*; q=0.01",
    "accept-language": "en-US,en;q=0.9",
    "priority": "u=0, i",
    "sec-ch-ua": "\"Chromium\";v=\"124\", \"Google Chrome\";v=\"124\", \"Not-A.Brand\";v=\"99\"",
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": "\"Windows\"",
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-site",
    "Referer": "https://www.niftyindices.com/",
    "Referrer-Policy": "strict-origin-when-cross-origin"
  },
  "body": null,
  "method": "GET"
}).then(res => res.json().then(data => {
  data.data.map(stock => {
    console.log(stock.symbol, stock.ltP);
    listStock(stock.symbol)
  })
}));
