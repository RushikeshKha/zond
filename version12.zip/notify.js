const express = require('express')
const app = express();
const { MongoClient, ObjectId } = require("mongodb");
const jwt = require('jsonwebtoken')
const nodemailer = require("nodemailer");



const port = 5000;
let inZone = []
let htmlTemplate = ""
let n;


app.use(express.json());
const client = new MongoClient("mongodb://127.0.0.1:27017");
function getSortedList(result) {//row.ltp - row.zone[0].baseHigh)/row.ltp
    return result.sort((a, b) => (((a['ltp'] - a['zone'][0]['chartData']['series'][0]['data'][0]['y'][1]) / a['ltp']) < ((b['ltp'] - b['zone'][0]['chartData']['series'][0]['data'][0]['y'][1]) / b['ltp']) ? -1 : 1))
}
function getDifference(array1, array2) {
    return array1.filter(object1 => {
        return !array2.some(object2 => {
            console.log("asdfasdf", object1.db === object2.ticker);
        });
    });
}


const transporter = nodemailer.createTransport({
    service: 'gmail',
    host: "smtp.gmail.com",
    port: 587,
    secure: false, // Use `true` for port 465, `false` for all other ports
    auth: {
        user: "notify.zoneseeker@gmail.com",
        pass: "orar ekbv grvg djdw",
    },
});




var getNotify = (res) => {
    inZone = []
    let a = []

    const dbs = ['NiftyOtherD','NiftyMidCap150D','NiftySmCap250D','NiftyOtherW','NiftySmCap250W','NiftyMidCap150W']

    async function run() {
        for (i = 0; i <= dbs.length - 1; i++) {
            try {
                await client.connect();
                const db = client.db("Zones")
                const cll = db.collection(dbs[i])
                const result = await cll.find({}).toArray()
                //console.log(time,oi)
                getSortedList(result).map((row, ind) => {
                    if (row.zone) { // Check if zone exists
                        a.push(row.ltp > row.zone[0].chartData.series[0].data[0].y[2] && row.ltp < row.zone[0].chartData.series[0].data[0].y[1] ? inZone.push({ db: dbs[i], ticker: row.ticker, type: row.zone[0].l }) : '')
                      } else {
                        console.log("Warning: row", ind, "has no zone property");
                      }
                    //a.push(row.ltp > row.zone[0].chartData.series[0].data[0].y[2] && row.ltp < row.zone[0].chartData.series[0].data[0].y[1] ? inZone.push({ db: dbs[i], ticker: row.ticker, type: row.zone[0].l }) : '')  
            })

            } catch (e) {
                if (e instanceof MongoError) {
                    console.log("Error connecting to MongoDB:", e.message);
                  } else {
                    console.log("Unexpected error:", e);
                  }
            } finally {
                await client.close();
            }
        }
        res.send(inZone)

    } run().catch(console.dir);
}

var Update = (res) => {
    async function run() {
        try {
            await client.connect();
            const db = client.db("Zones")
            const cll = db.collection('notify')
            const result = await cll.updateOne({ _id: new ObjectId("660825e6bb520bfa48a1af74") }, { $set: { data: inZone } })
            //const result = await cll.insertOne({ data: inZone })
            inZone = []
            res.send(result)
        } catch (e) {
            console.log("Error:Update " + "{time:" + e + "}");
        } finally {
            await client.close();
        }
    } run().catch(console.dir);

}
var Notify = (res) => {
    async function run() {
        try {
            await client.connect();
            const db = client.db("Zones")
            const cll = db.collection('notify')
            const result = await cll.find({}).toArray()
            if (JSON.stringify(inZone) == JSON.stringify(result[0].data)) {
                res.send(true)
            } else {
                if (inZone.length > result[0].data.length) {
                    const objectsNotInFirstArray = inZone.filter(obj2 => {
                        // Check if any object in firstArray has the same "ticker"
                        return !result[0].data.some(obj1 => obj1.ticker === obj2.ticker);
                    });

                    console.log("db", result[0].data.length)
                    console.log("inZone", inZone.length)
                    for (n in objectsNotInFirstArray) {
                        htmlTemplate += "<tr><td>" + objectsNotInFirstArray[n].type + "</td><td>" + objectsNotInFirstArray[n].ticker + "</td><td>" + objectsNotInFirstArray[n].db + "</td></tr>"
                    }
                    transporter.sendMail({
                        from: 'notify.zoneseeker@gmail.com',
                        to: 'rushikeshkhadikar1@gmail.com',
                        subject: 'Demand Zone Notification',
                        html: `
                        <table>
                        <tr>
                        <th>Type</th>
                        <th>Sector</th>
                        <th>Name</th>
                        </tr>
                        `+htmlTemplate+`
                      </table>
                        `
                    }, function (error, info) {
                        if (error) {
                            console.log(error);
                        } else {
                            console.log('Email sent: ' + info.response);
                            htmlTemplate = ""
                        }
                    });
                    console.log(objectsNotInFirstArray);
                    res.send("Add: "+JSON.stringify(objectsNotInFirstArray))
                } else if (inZone.length < result[0].data.length) {
                    const objectsNotInFirstArray = result[0].data.filter(obj2 => {
                        // Check if any object in firstArray has the same "ticker"
                        return !inZone.some(obj1 => obj1.ticker === obj2.ticker);
                    });

                    console.log("db", result[0].data.length)
                    console.log("inZone", inZone.length)
                    for (n in objectsNotInFirstArray) {
                        htmlTemplate += "<tr><td>" + objectsNotInFirstArray[n].type + "</td><td>" + objectsNotInFirstArray[n].ticker + "</td><td>" + objectsNotInFirstArray[n].db + "</td></tr>"
                    }

                    console.log(objectsNotInFirstArray);
                    res.send("Delete: "+JSON.stringify(objectsNotInFirstArray))
                }
            }
        } catch (e) {
            console.log("Error:Notify " + "{time:" + e + "}");
        } finally {
            await client.close();
        }
    } run().catch(console.dir);

}

app.get('/inZone', (req, res) => {
    getNotify(res)
})

app.get('/update', (req, res) => {
    Update(res)
})

app.get('/notify', (req, res) => {
    Notify(res)
})

app.listen(port, () => {
    console.log(`Notigy app listening on port ${port}`)
})

